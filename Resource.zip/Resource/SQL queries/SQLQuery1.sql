SELECT * FROM CAW01_14

-- Step 1: Drop the unnamed column if it exists
ALTER TABLE CAW01_14
DROP COLUMN IF EXISTS "column1";

-- Step 2: Convert all state/UT names to lowercase
UPDATE CAW01_14
SET "STATE_UT" = LOWER("STATE_UT");

-- Step 3: Replace inconsistent variations with standardized names
UPDATE CAW01_14
SET "STATE_UT" = CASE
    WHEN "STATE_UT" = 'a&n islands' THEN 'a & n islands'
    WHEN "STATE_UT" = 'd&n haveli' THEN 'd & n haveli'
    WHEN "STATE_UT" = 'delhi ut' THEN 'delhi'
    ELSE "STATE_UT"
END;

-- Optional Step: View unique state names to ensure there are no more inconsistencies
SELECT DISTINCT "STATE_UT"
FROM CAW01_14
ORDER BY STATE_UT;