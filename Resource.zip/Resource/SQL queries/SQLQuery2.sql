-- 1. Total Crimes by Year

SELECT Year, SUM(Rape + "Kidnapping_and_Abduction" + "Dowry_Deaths" + 
                 "Assault_on_women_with_intent_to_outrage_her_modesty" +
                 "Insult_to_modesty_of_Women" + "Cruelty_by_Husband_or_his_Relatives" + 
                 "Importation_of_Girls") AS Total_Crimes
FROM CAW01_14
GROUP BY Year
ORDER BY Total_Crimes desc;
