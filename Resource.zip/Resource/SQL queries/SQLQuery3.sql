-- 2. State with the Highest Number of Crimes

SELECT TOP 1 STATE_UT, SUM(Rape + Kidnapping_and_Abduction + Dowry_Deaths + 
                     Assault_on_women_with_intent_to_outrage_her_modesty +
                     Insult_to_modesty_of_Women + Cruelty_by_Husband_or_his_Relatives + 
                     Importation_of_Girls) AS Total_Crimes
FROM CAW01_14
GROUP BY STATE_UT
ORDER BY Total_Crimes DESC;
