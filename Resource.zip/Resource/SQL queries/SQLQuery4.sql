-- 3. Top 5 Districts with the Highest Rape Cases

SELECT TOP 5 DISTRICT, SUM(Rape) AS Total_Rape_Cases
FROM CAW01_14
GROUP BY DISTRICT
ORDER BY Total_Rape_Cases DESC;
