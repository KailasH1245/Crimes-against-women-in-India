-- 4. Crime Breakdown by State

SELECT STATE_UT, 
       SUM(Rape) AS Total_Rape, 
       SUM(Kidnapping_and_Abduction) AS Total_Kidnapping, 
       SUM(Dowry_Deaths) AS Total_Dowry_Deaths, 
       SUM(Assault_on_women_with_intent_to_outrage_her_modesty) AS Total_Assault, 
       SUM(Insult_to_modesty_of_Women) AS Total_Insult, 
       SUM(Cruelty_by_Husband_or_his_Relatives) AS Total_Cruelty, 
       SUM(Importation_of_Girls) AS Total_Importation
FROM CAW01_14
-- WHERE STATE_UT = 'uttar pradesh' -- Replace with the state having the highest crimes
GROUP BY STATE_UT
ORDER BY STATE_UT;


