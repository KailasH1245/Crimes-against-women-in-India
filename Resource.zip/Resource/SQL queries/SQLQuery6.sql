-- 5. Top 5 States with the Most Dowry Deaths

SELECT TOP 5 STATE_UT, SUM(Dowry_Deaths) AS Total_Dowry_Deaths
FROM CAW01_14
GROUP BY STATE_UT
ORDER BY Total_Dowry_Deaths DESC;
