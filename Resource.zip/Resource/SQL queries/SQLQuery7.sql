-- 6. Year-on-Year Growth Rate of Rape Cases

WITH Yearly_Rape AS (
    SELECT Year, SUM(Rape) AS Total_Rape
    FROM CAW01_14
    GROUP BY Year
)
SELECT Year, 
       Total_Rape, 
       (Total_Rape - LAG(Total_Rape) OVER (ORDER BY Year)) * 100.0 / LAG(Total_Rape) OVER (ORDER BY Year) AS Growth_Rate
FROM Yearly_Rape;
