-- 7. Crimes with the Largest Decrease Over Time

WITH Crime_Trends AS (
    SELECT Year, 
           SUM(Rape) AS Rape, 
           SUM(Kidnapping_and_Abduction) AS Kidnapping, 
           SUM(Dowry_Deaths) AS Dowry_Deaths, 
           SUM(Assault_on_women_with_intent_to_outrage_her_modesty) AS Assault, 
           SUM(Insult_to_modesty_of_Women) AS Insult, 
           SUM(Cruelty_by_Husband_or_his_Relatives) AS Cruelty, 
           SUM(Importation_of_Girls) AS Importation
    FROM CAW01_14
    GROUP BY Year
)
SELECT 'Rape' AS Crime_Type, (SELECT Rape FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Rape FROM Crime_Trends WHERE Year = 2001) AS Decrease
UNION
SELECT 'Kidnapping', (SELECT Kidnapping FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Kidnapping FROM Crime_Trends WHERE Year = 2001) AS Decrease
UNION
SELECT 'Dowry Deaths', (SELECT Dowry_Deaths FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Dowry_Deaths FROM Crime_Trends WHERE Year = 2001) AS Decrease
UNION
SELECT 'Assault', (SELECT Assault FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Assault FROM Crime_Trends WHERE Year = 2001) AS Decrease
UNION
SELECT 'Insult', (SELECT Insult FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Insult FROM Crime_Trends WHERE Year = 2001) AS Decrease
UNION
SELECT 'Cruelty', (SELECT Cruelty FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Cruelty FROM Crime_Trends WHERE Year = 2001) AS Decrease
UNION
SELECT 'Importation', (SELECT Importation FROM Crime_Trends WHERE Year = 2014) - 
       (SELECT Importation FROM Crime_Trends WHERE Year = 2001) AS Decrease
ORDER BY Decrease ASC;
