-- 8. State-wise Trend of Crimes Against Women

SELECT Year, STATE_UT, 
       SUM(Rape + Kidnapping_and_Abduction + Dowry_Deaths + 
           Assault_on_women_with_intent_to_outrage_her_modesty +
           Insult_to_modesty_of_Women + Cruelty_by_Husband_or_his_Relatives + 
           Importation_of_Girls) AS Total_Crimes
FROM CAW01_14
WHERE STATE_UT IN ('uttar pradesh', 'andhra pradesh', 'west bengal') -- Replace with states of interest
GROUP BY Year, STATE_UT
ORDER BY Year, STATE_UT;
